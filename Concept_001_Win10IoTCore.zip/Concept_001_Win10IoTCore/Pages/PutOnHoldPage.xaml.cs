﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using System.Threading;
using Concept_001_Win10IoTCore.Controls;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace Concept_001_Win10IoTCore.Pages
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class PutOnHoldPage : Page
    {
        string prod_name = "";
        string prod_number = "";
        string prod_rev = "";
        string prod_sno = "";
        string prod_status = "";

        public PutOnHoldPage()
        {
            this.InitializeComponent();
        }

        private void on_hold_back_btn_Click(object sender, RoutedEventArgs e)
        {
            Frame.GoBack();
        }

        private void enter_btn_Click(object sender, RoutedEventArgs e)
        {
            summary_log_txt.Text = "";
            enter_btn.IsEnabled = false;

            if (serial_txt.Text != null)
            {
                //Check for http response from server and get the data
            }

            summary_log_txt.FontSize = 36;
            summary_log_txt.Text += "Product name: " + prod_name + "\n\n";
            summary_log_txt.Text += "Product number: " + prod_number + "\n\n";
            summary_log_txt.Text += "Product revision: " + prod_rev + "\n\n";
            summary_log_txt.Text += "Serial number: " + prod_sno + "\n\n";
            summary_log_txt.Text += "Production status: " + prod_status + "\n\n";


            enter_btn.IsEnabled = true;

            Thread.Sleep(2000);
            //Frame.Navigate(typeof(GiveAccessPage));
        }

        private async void open_box_btn_Click(object sender, RoutedEventArgs e)
        {
            if ((box_num_txt.Text != null) && (box_num_txt.Text != ""))
            {
                //Send I2C command to STM32
                await Communication.FindDevicesAsync();
                
            }
        }
    }
}
