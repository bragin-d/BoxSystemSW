﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.Devices.Enumeration;
using Windows.Devices.I2c;
using System.Diagnostics;

namespace Concept_001_Win10IoTCore.Controls
{
    class Communication
    {

		public static async Task<IEnumerable<byte>> FindDevicesAsync()
		{
			IList<byte> returnValue = new List<byte>();

			// *** 
			// *** Get a selector string that will return all I2C controllers on the system
			// *** 
			string aqs = I2cDevice.GetDeviceSelector();

			// *** 
			// *** Find the I2C bus controller device with our selector string 
			// *** 
			var dis = await DeviceInformation.FindAllAsync(aqs).AsTask();

			if (dis.Count > 0)
			{
				const int minimumAddress = 0x08;
				const int maximumAddress = 0x77;

				for (byte address = minimumAddress; address <= maximumAddress; address++)
				{
					var settings = new I2cConnectionSettings(address);
					settings.BusSpeed = I2cBusSpeed.FastMode;
					settings.SharingMode = I2cSharingMode.Shared;

					// *** 
					// *** Create an I2cDevice with our selected bus controller and I2C settings 
					// *** 
					using (I2cDevice device = await I2cDevice.FromIdAsync(dis[0].Id, settings))
					{
						if (device != null)
						{
							try
							{
								byte[] writeBuffer = new byte[1] { 0 };
								device.Write(writeBuffer);

								// *** 
								// *** If no exception is thrown, there is 
								// *** a device at this address. 
								// *** 
								returnValue.Add(address);
							}
							catch
							{
								// *** 
								// *** If the address is invalid, an exception will be thrown. 
								// *** 

								Debug.WriteLine("No device at " + address);
							}
						}
					}
				}
			}

			return returnValue;
		}

	}
}
